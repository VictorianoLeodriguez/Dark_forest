// other_hit.gml
sprite_index = spr_enemy_hit;
image_index  = 0;
alarm[0]     = 30;
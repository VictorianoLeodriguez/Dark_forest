//--------------------------------------
// obj_enemy — Step Event
//--------------------------------------
/// 1) Verifica se o player existe e está dentro do alcance
if (instance_exists(Menina)) {
    var px   = Menina.x;
    var py   = Menina.y;
    var dist = point_distance(x, y, px, py);
    
    // acende flag de perseguição
    if (dist < detect_range) {
        chasing = true;
    }
    
    // opcional: desliga perseguição se player sumir ou fugir muito
    // else chasing = false;
    
    /// 2) Estado de perseguição
    if (chasing) {
        // mover em direção ao player
        move_towards_point(px, py, chase_speed);
        
        // inverter a sprite para olhar na direção do player
        if (px < x) image_xscale = -1;
        else          image_xscale =  1;
        
        // trocar pra animação de correr
        if (sprite_index != fantasma) {
            sprite_index = fantasma;
            image_speed  = 0.3;
        }
    }
    else {
        // estado “idle” antes de detectar
        if (sprite_index != fantasma) {
            sprite_index = fantasma;
            image_speed  = 0.15;
        }
    }
}



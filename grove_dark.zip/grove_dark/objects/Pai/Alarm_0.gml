instance_destroy();

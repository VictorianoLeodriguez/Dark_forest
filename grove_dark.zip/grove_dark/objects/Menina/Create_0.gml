up = noone;
down = noone;
left = noone;
right = noone;

velh = 0;
velv = 0;

vel = 2;

// obj_player – Create Event
attacking     = false;    // flag de ataque em andamento
attack_frame  = 1;        // qual frame da animação conta como golpe
attack_checked = false;   // para não repetir a checagem

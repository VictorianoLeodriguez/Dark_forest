// obj_player – Key Press Space
if (!attacking) {
    attacking      = true;
    attack_checked = false;
    sprite_index   = Attack  // sua sprite de ataque
    image_index    = 0;                   // começa do frame 0
}
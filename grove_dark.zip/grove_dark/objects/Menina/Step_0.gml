up = keyboard_check(vk_up);
down = keyboard_check(vk_down);
left = keyboard_check(vk_left);
right = keyboard_check(vk_right);

if keyboard_check(vk_up or vk_down or vk_left or vk_right) {
	sprite_index= sMove
}
else {
	sprite_index = Idle
}

if keyboard_check(vk_space) {
	sprite_index= Attack 
}

velv = (down - up) * vel;

velh = (right - left) * vel;

if (left) {
    image_xscale = +1;
}
else if (right) {
    image_xscale = -1;
}


// obj_player – Step Event

if (attacking) {
    // 1) Durante o frame ativo, verifica colisão 1 única vez
    if (image_index == attack_frame && !attack_checked) {
        var inst = instance_place(x + sprite_width/2, y, Pai);
        if (inst) {
            with (inst) {
                // chama o evento de “levar golpe”
                other_hit();
            }
        }
        attack_checked = true;
    }

    // 2) Ao terminar a animação, volta ao estado normal
    if (image_index >= image_number - 1) {
        attacking    = false;
        sprite_index = Idle;  
    }
}

if (attacking && image_index == attack_frame && !attack_checked) {
    var hit_x = x + (image_xscale > 0 ? sprite_width/2 : -sprite_width/2);
    var hit_y = y;
    var inst  = instance_place(hit_x, hit_y, Pai);
    if (inst) with (inst) other_hit();
    attack_checked = true;
}


//--------------------------------------
// obj_enemy — Create Event
//--------------------------------------
chase_speed   = 2;     // pixels/step que o inimigo anda
detect_range  = 300;   // distância máxima para “ligar” a perseguição
chasing       = false; // flag de estado
image_speed   = 0.2;   // velocidade base das animações